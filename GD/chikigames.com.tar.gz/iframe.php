<!doctype html>

<head>
<title><?php $lines = file('title.txt'); echo $lines[array_rand($lines)]; ?> &#8211; ChikiGames</title>
<meta name="description" content="Planning to travel internationally on a one-way ticket? You might have a problem. Some airlines and countries require proof of onward travel. Here&#039;s how you can get it."/>
<meta name="keywords" content="deal, deals, iphone, mac, macbook, apple, business, money, insurance, car Insurance,Loans, Mortgage, Attorney, Credit, Lawyer, Donate, Degree, Hosting,Claim, motor, bmw, toyota, ferari" />

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<style type="text/css">
body {
background-color: black;

overflow: hidden;
margin: 0;
  }
 div {
  background-color: grey;
} 
</style>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-149756083-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149756083-1');
</script>


</head>

<body>
<center>
<iframe src="/1.html" width="390px" height="650px" scrolling="no" frameborder="0"></iframe>
<iframe src="/2.html" width="390px" height="650px" scrolling="no" frameborder="0"></iframe>
<iframe src="/3.html" width="390px" height="650px" scrolling="no" frameborder="0"></iframe>
<iframe src="/4.html" width="390px" height="650px" scrolling="no" frameborder="0"></iframe>

<div>
<?php
echo $_SERVER['REMOTE_ADDR'];
echo "<br>";
$ip_list = getenv('HTTP_X_FORWARDED_FOR');
echo $ip_list;
echo "<br>";
$ref = getenv("HTTP_REFERER");
echo "Ref: $ref <br>";
$browser_type = getenv("HTTP_USER_AGENT");
echo "UA: $browser_type.";
echo "<br>";
$xml = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".getRealIpAddr());
echo $xml->geoplugin_countryName ;


echo "<pre>";
foreach ($xml as $key => $value)
{
    echo $key , "= " , $value ,  " \n" ;
}
echo "</pre>";
function getRealIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

?>
</div>



</center>
      </body>                          
</html>

</body>
</html>